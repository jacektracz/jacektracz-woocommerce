<?php

interface Przelewy24Interface
{
    public function setTranslations();
}