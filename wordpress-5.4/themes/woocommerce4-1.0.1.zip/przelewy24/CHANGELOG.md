# ChangeLog

##[1.0.1]  - 2020-03-30
- Statistical section integrated

##[1.0.0]  - 2020-03-20
- migration to Woo 4.x without satistic section
