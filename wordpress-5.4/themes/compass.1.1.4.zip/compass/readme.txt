Compass WordPress Theme Documentation By InkThemes.

Get Your Website Ready in Just 1 Click.

Thank you for trying the Compass WordPress Theme. If you have any questions that are beyond the scope of this readme file, please feel free to ask questions at InkThemes Support Forum. Follow the link given below:
http://www.inkthemes.com/community/

License and resources links for images:
---------------------------------------
1.jpg
Source: http://pixabay.com/en/child-girl-snow-lighting-562070/

2.jpg
Source: http://pixabay.com/en/keyboard-apple-input-keys-hardware-338510/

All Other Images are created by InkThemes and are fully GPL License Compatible.

License and resources links for scripts and css
---------------------------------------

1. slitslider.js
/**
* jquery.slitslider.js v1.1.0
* http://www.codrops.com
*
* Licensed under the MIT license.
* http://www.opensource.org/licenses/mit-license.php
* 
* Copyright 2012, Codrops
* http://www.codrops.com
*/
 
2. jquery.ba-cond.min.js
* cond - v0.1 - 6/10/2009
* http://benalman.com/projects/jquery-cond-plugin/
* 
* Copyright (c) 2009 "Cowboy" Ben Alman
* Licensed under the MIT license
* http://benalman.com/about/license/
* 
* Based on suggestions and sample code by Stephen Band and DBJDBJ in the
* jquery-dev Google group: http://bit.ly/jqba1

3. Animate.css 
Animate.css - http://daneden.me/animate
Licensed under the MIT license


4. jquery.meanmenu.2.0.js
* jQuery meanMenu v2.0.8
* @Copyright (C) 2012-2014 Chris Wharton @ MeanThemes (https://github.com/meanthemes/meanMenu)

* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.

5. superfish.js
* Superfish v1.4.8 - jQuery menu widget
* Copyright (c) 2008 Joel Birch
*
* 	Dual licensed under the MIT and GPL licenses:
* 	http://www.opensource.org/licenses/mit-license.php
* 	http://www.gnu.org/licenses/gpl.html

6. 960_24_col_responsive.css
	960 Grid System Modified for
	Responsive layout 960 Grid 
	System ~ Core CSS.
	Learn more ~ http://960.gs/    
	Author: InkThemes
	Licensed under GPL and MIT.

7.  Font Awesome is completely free for commercial use. Check out the license linlk below.
	http://fortawesome.github.io/Font-Awesome/license/
	
8.  google font information
	http://www.google.com/fonts#UsePlace:use/Collection:Roboto+Slab